#!/usr/bin/python

print "Content-type: text/html"
print
print "<p>Hello World!</p>"
