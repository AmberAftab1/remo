#!/bin/bash

python -m CGIHTTPServer 8080
